## Shared data directory

This is a shared data directory.

* Files under the `fcrepo/` directory are managed by the Fedora repository
